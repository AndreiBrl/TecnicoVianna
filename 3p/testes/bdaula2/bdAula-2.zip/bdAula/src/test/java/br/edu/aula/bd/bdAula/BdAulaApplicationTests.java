package br.edu.aula.bd.bdAula;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BdAulaApplicationTests {

	@Test
	void contextLoads() {
	}

}
