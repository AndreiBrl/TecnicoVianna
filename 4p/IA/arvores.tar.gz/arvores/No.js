class No{

    valor= "";
    filhos=[];

    constructor(valor){
        
        this.valor=valor;


    }
    addFilho(no)
{
    if(no instanceof No){


        this.filhos.push(no);
        }else{
            throw new Error ('Error espareado um nó como filho')
        }
}}
export default No;