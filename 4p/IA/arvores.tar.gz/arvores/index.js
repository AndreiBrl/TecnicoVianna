import Arvore from "./Arvore.js";
import No from "./No.js";

let arvore = new Arvore("A");

let noB = new No("B")
let noC = new No("C")
let noD = new No("D")

arvore.raiz.addFilho(noB)
arvore.raiz.addFilho(noC)
noC.addFilho(noD)
console.log(arvore.raiz);
